package goober_maths

object gMath {

  def randomRange (start : Int, end : Int) = {
    val rnd = new scala.util.Random
    start + rnd.nextInt( (end - start) + 1 )
  }

}

case class Vector3(var x: Byte, var y: Byte, var z: Byte) {
  def + (v: Vector3) : Vector3 = {
    new Vector3((x+v.x).toByte, (y+v.y).toByte, (z+v.z).toByte)
  }

  /*def += (v: Vector3) {
    this = this + v
  }*/

  def - (v: Vector3) : Vector3 = {
    new Vector3((x-v.x).toByte, (y-v.y).toByte, (z-v.z).toByte)
  }

  /*def -= (v: Vector3) {
    this = this - v
  }*/

  def * (v: Vector3) : Vector3 = {
    new Vector3((x*v.x).toByte, (y*v.y).toByte, (z*v.z).toByte)
  }

  /*def *= (v: Vector3) {
    this = this * v
  }*/

  def / (v: Vector3) : Vector3 = {
    new Vector3((x/v.x).toByte, (y/v.y).toByte, (z/v.z).toByte)
  }

  /*def /= (v: Vector3) {
    this = this / v
  }*/
}