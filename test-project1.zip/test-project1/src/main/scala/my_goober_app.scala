package goober_app

import goober_graphics._
import scala_goober._
import goober_physics._
import goober_maths._

object Goob {

  //sprites
  val Ball = new Sprite( Array( new Pixel(3,0,0x33), new Pixel(4,0,0x33), new Pixel(2,1,0x33), new Pixel(5,1,0x33),
    new Pixel(3,3,0x33), new Pixel(4,3,0x33), new Pixel(2,2,0x33), new Pixel(5,2,0x33)) )

  val Square = new Sprite( Array( new Pixel(1,0,0x3c), new Pixel(2,0,0x3c), new Pixel(1,1,0x30), new Pixel(2,1,0x38) ))

  val Line = new Sprite( Array( new Pixel(1,0,0x3c), new Pixel(2,0,0x34), new Pixel(3,0,0x30), new Pixel(4,0,0x38),
    new Pixel(5,0,0x07), new Pixel(6,0,0x0c), new Pixel(7,0,0x33), new Pixel(8,0,0x31)))

  //goobs
  val myGoobs = Map(
    "myLine" -> new GoobObj {
      transform.position = new Vector3(6,6,0)
      sprite = Line
    },
    "myBall" -> new GoobObj {
      transform.position = new Vector3(3,2,0)
      sprite = Ball
    },
    "mySquare" -> new GoobObj {
      transform.position = new Vector3(1,5,0)
      sprite = Square
    }
  )


  def Start {
    println("It works")
    Main.graphics.setBG(0x01)
  }

  def GoobLoop {
    Main.graphics.setBG(0x01)
  }

  def keyPress (c: Char) {
    c match {
      case 'D' => myGoobs("myBall").transform.position.x = (1 + myGoobs("myBall").transform.position.x).toByte
      case 'A' => myGoobs("myBall").transform.position.x = (1 - myGoobs("myBall").transform.position.x).toByte
      case 'W' => myGoobs("myBall").transform.position.y = (1 - myGoobs("myBall").transform.position.y).toByte
      case 'S' => myGoobs("myBall").transform.position.y = (1 + myGoobs("myBall").transform.position.y).toByte
    }
  }

  def keyRelease (c: Char) {

  }

}