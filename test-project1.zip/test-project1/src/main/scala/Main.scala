package scala_goober
import goober_colors._
import java.awt._
import scala.swing._
import goober_graphics._
import goober_maths._
import goober_app._
import scala.collection.mutable.ListBuffer
import goober_physics._
import scala.swing.event._
import scala.collection.immutable.ListMap

object Main {

  val fpsInterval = 20
  var gameTime = 0
  val Goobs = new ListBuffer[GoobObj]
  val appTitle = "test"
  val graphics = new MyPanel {
    reactions += {
      case KeyPressed(_, c, _, _) => Goob.keyPress(c.toString.head)
      //case KeyTyped(_, c, _, _) => println("tp "+c)
      case KeyReleased(_, c, _, _) => Goob.keyRelease(c.toString.head)
    }
  }
  Start
  lazy val mf = new MainFrame {
    title = appTitle
    contents = graphics
    background = gColor.toGColor(0x00)
    graphics.repaint()
    size=(new Dimension(248,144))
    centerOnScreen()
  }

  def main(args: Array[String]): Unit = {
    //nuffin
  }

  def Start {
    mf.open()             //open window
    graphics.setBG(0x32)  //set standard background to pink. if screen does not start pink, something's wrong
    startLog              //print APP STARTED in the console
    Goob.Start
    Main                  //start the main loop
  }

  def Main {
    gameTime += 1
    if(gameTime % fpsInterval == 0) {
      render
      gameLoop
    }
    postRender
    Main
  }

  def gameLoop {
      Goob.GoobLoop
  }

  def render {
    graphics.h = mf.size.height/graphics.screenY
    graphics.w = graphics.h
    for((n,g)<-Goob.myGoobs if (!Goobs.contains(g)))  Goobs += g
  }

  def postRender {
    Goobs.sortWith(_.transform.position.z > _.transform.position.z)
    for (g<-Goobs.toList) {
      g.sprite.draw(graphics, new Dimension(g.transform.position.x, g.transform.position.y))
    }

    if(Goobs.length == Goob.myGoobs.size) {
      graphics.repaint()
      mf.repaint()
    }
  }

  def testWindow {
    val x = gMath.randomRange(0, graphics.screenX-1)
    val y = gMath.randomRange(0, graphics.screenY-1)
    val c = gMath.randomRange(-128,63)
    graphics.setPixel(x, y, c.toByte)
    graphics.setPixel(3, 3, (0xff).toByte)
  }

  //package ASCII_logger {

    def ***(inter: String, s: String) {
      s.toLowerCase.foreach(c => printASCII(c, inter))
    }

    def printASCII(char: Char, inter: String) {
      char match {
        case 'a' => println(
          s"   __    $inter" +
            s"  /  \\   $inter" +
            s" / /\\ \\  $inter" +
            s"| |--| | $inter" +
            s"| |  | | $inter")
        case 'b' => println(
          s"____  $inter" +
            s"|   \\ $inter" +
            s"| ' / $inter" +
            s"| , \\ $inter" +
            s"|___/ $inter")
        case 'c' => println(
          s"  ____  $inter" +
            s" / ___\\ $inter" +
            s"| |     $inter" +
            s"| |___  $inter" +
            s" \\____/ $inter")
        case 'd' => println(
          s"_____   $inter" +
            s"\\    \\  $inter" +
            s"|  |  | $inter" +
            s"|  |  | $inter" +
            s"/____/  $inter")
        case 'e' => println(
          s"====== $inter" +
            s"||     $inter" +
            s"|====  $inter" +
            s"||     $inter" +
            s"====== $inter")
        case 'f' => println(
          s"======= $inter" +
            s"||      $inter" +
            s"| ===   $inter" +
            s"||      $inter" +
            s"||      $inter")
        case 'g' => println(
          s"  ____   $inter" +
            s" / ___\\  $inter" +
            s"| / ___  $inter" +
            s"| \\|__ \\ $inter" +
            s" \\____/  $inter")
        case 'h' => println(
          s"____  ____ $inter" +
            s" ||    ||  $inter" +
            s" ||    ||  $inter" +
            s" ||====||  $inter" +
            s"_||_  _||_ $inter")
        case 'i' => println(
          s"____ $inter" +
            s" ||  $inter" +
            s" ||  $inter" +
            s" ||  $inter" +
            s"_||_ $inter")
        case 'j' => println(
          s" ==== $inter" +
            s"  ||  $inter" +
            s"_ ||  $inter" +
            s"\\\\||  $inter" +
            s" \\_/  $inter")
        case 'k' => println(
          s"|-|  /-/ $inter" +
            s"| | / /  $inter" +
            s"| |/ /   $inter" +
            s"| |\\ \\   $inter" +
            s"|_| \\_\\  $inter")
        case 'l' => println(
          s"|=|     $inter" +
            s"| |     $inter" +
            s"| |     $inter" +
            s"| |___  $inter" +
            s"|____|  $inter")
        case 'm' => println(
          s"|=\\  /=|  $inter" +
            s"| |\\/| |  $inter" +
            s"| |\\_/| | $inter" +
            s"| |   | | $inter" +
            s"|_|   |_| $inter")
        case 'n' => println(
          s"|==\\  |=| $inter" +
            s"|   \\ | | $inter" +
            s"| |\\ \\| | $inter" +
            s"| | \\   | $inter" +
            s"|_|  \\__/ $inter")
        case 'o' => println(
          s"  _____   $inter" +
            s" /  _  \\  $inter" +
            s"|  / \\  | $inter" +
            s"|  \\_/  | $inter" +
            s" \\_____/  $inter")
        case 'p' => println(
          s"=====_  $inter" +
            s"|  ,  | $inter" +
            s"|  __/  $inter" +
            s"| |     $inter" +
            s"|_|     $inter")
        case 'q' => println(
          s"  _____    $inter" +
            s" /  _  \\   $inter" +
            s"|  / \\  |  $inter" +
            s"|  \\_/\\\\|  $inter" +
            s" \\_____\\\\_ $inter")
        case 'r' => println(
          s"_____    $inter" +
            s"|  _ \\   $inter" +
            s"| | \\ |  $inter" +
            s"| | / /  $inter" +
            s"| |\\ \\   $inter" +
            s"| | \\ \\  $inter")
        case 's' => println(
          s" __    $inter" +
            s"/  \\   $inter" +
            s"\\ \\/   $inter" +
            s"/\\ \\   $inter" +
            s"\\__/   $inter")
        case 't' => println(
          s"______ $inter" +
            s"--  -- $inter" +
            s"  ||   $inter" +
            s"  ||   $inter" +
            s"  ||   $inter")
        case 'u' => println(
          s"====  ==== $inter" +
            s" ||    ||  $inter" +
            s" ||    ||  $inter" +
            s" ||____||  $inter" +
            s"  \\\\___//  $inter")
        case 'v' => println(
          s"___    ___ $inter" +
            s" \\\\    //  $inter" +
            s"  \\\\  //   $inter" +
            s"   \\\\//    $inter" +
            s"   _\\/_    $inter")
        case 'w' => println(
          s"___      ___ $inter" +
            s" \\\\ _  _ //  $inter" +
            s"  \\\\ \\/  //  $inter" +
            s"   \\\\/\\//    $inter" +
            s"   _\\/\\/_    $inter")
        case 'x' => println(
          s"====  ==== $inter" +
            s"  \\\\  //   $inter" +
            s"   \\\\//    $inter" +
            s"   //\\\\    $inter" +
            s" _//  \\\\_  $inter")
        case 'y' => println(
          s"===  === $inter" +
            s" \\\\  //  $inter" +
            s"  \\\\//   $inter" +
            s"   ||    $inter" +
            s"  _||_   $inter")
        case 'z' => println(
          s"=====/ $inter" +
            s"   //  $inter" +
            s"  //   $inter" +
            s" //    $inter" +
            s"/===== $inter")
        case ' ' => println(
          s"         $inter" +
            s"-------- $inter" +
            s"-------- $inter" +
            s"         $inter")
        case '!' => println(
          s"|==| $inter" +
            s"|  |  $inter" +
            s"|  |  $inter" +
            s" \\/   $inter" +
            s" /\\   $inter" +
            s" \\/ $inter")
        case '?' => println(
          s"  ____  $inter" +
            s" / _  \\ $inter" +
            s"| |_|  | $inter" +
            s" \\_// / $inter" +
            s"    \\/  $inter" +
            s"    /\\  $inter" +
            s"    \\/  $inter")
      }
    }

    def startLog {
      println(Console.BLUE)
      ***(s"* started: $appTitle\n", "APP STARTED! ")
      println(Console.WHITE + "------------------------------------------------\n")
    }

  //}

}