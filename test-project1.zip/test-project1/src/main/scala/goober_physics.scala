package goober_physics
import scala.collection.mutable.ListBuffer
import goober_maths._
import goober_graphics._
import java.awt._

class Transform {
  var position = new Vector3(0,0,0)
  var parent : Transform = null
  var children = new ListBuffer[Transform]

  def localPosition : Vector3 = {
    if(parent == null) {
      position
    } else {
      position - parent.position
    }
  }

  def transform(v: Vector3){
    position = position + v
    for(c<-children) c.position = c.position + v
  }

}

class GoobObj {
  val transform = new Transform
  var sprite : Sprite = null
  var bounds : Dimension = new Dimension(1,1) //goes 1 left, 1 right, 1 up, 1 down
}