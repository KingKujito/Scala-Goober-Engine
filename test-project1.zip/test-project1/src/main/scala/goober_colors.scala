package goober_colors
import java.awt._

object gColor {

  //colors go from val 0-3 (in binary)
  def toGColor(b: Byte) = {
    new Color( ((b & 0x30)>>>4)*85 , ((b & 0x0C)>>>2)*85 , (b & 0x03)*85)
  }

  def getTrigger(b: Byte) = {
    (b>>>6).toByte
  }
}