package goober_graphics

import java.awt._
import scala.swing._
import goober_colors._
import scala.swing.event._


class MyPanel extends scala.swing.Panel {
//object gGraphics {
  var w = 5
  var h = 5
  val screenX = 255
  val screenY = 144
  val pixels = new Array[Byte](screenX*screenY)

  //clear only the colors of each pixel
  def Clear {
    for(i<-0 to pixels.length-1){
      val c = pixels(i)
      pixels(i) = ((c>>>6)<<6).toByte
    }
  }

  //clear only the colors of each pixel
  def setBG (b: Byte) {
    for(i<-0 to pixels.length-1){
      val c = pixels(i)
      pixels(i) = ((c>>>6)<<6).toByte
      pixels(i) = (pixels(i) | b).toByte
    }
  }

  //set pixel color and trigger
  def setPixel (x : Int, y : Int, b: Byte) {
    pixels(dimToInd(x,y)) = b
  }

  //getPixelByte
  def getPixel (x : Int, y : Int) : Byte = {
    pixels(dimToInd(x,y))
  }

  //getPixel Color
  def getPixelColor (x : Int, y : Int) : Byte = {
    ((pixels(dimToInd(x,y))<<2)>>>2).toByte
  }

  //getPixelByte
  def getPixelTrigger (x : Int, y : Int) : Byte = {
    ((pixels(dimToInd(x,y))>>>6)<<6).toByte
  }

  def dimToInd (x: Int, y: Int) : Int = {
    var y1 = y
    var x1 = x
    if (y >= screenY) {
      y1 = 0
    } else if (y < 0) {
      y1 = screenY-1
    }

    if (x >= screenX) {
      x1 = 0
    } else if (x < 0) {
      x1 = screenY-1
    }
    x1 + y1*screenX
  }

    override def paint (g: Graphics2D) {
      for(i<-0 to pixels.length-1) {
        g.setColor( gColor.toGColor(pixels(i)) )
        //g.fill(new Rectangle(i%screenX * w, math.floor(i/screenX).toInt * h, w, h))
        g.fillArc(i%screenX * w, math.floor(i/screenX).toInt * h, w, h, 0, 360)

        //g.setColor( Color.black )
        //g.draw(new Rectangle(i%screenX * w, math.floor(i/screenX).toInt * h, w, h))
      }
    }

  focusable = true
  listenTo(keys)
  /*reactions += {
    case KeyPressed(_, c, _, _) => println(c)
  }*/

}

class Sprite(Pixels : Array[Pixel]) {

  def draw (g: MyPanel, offset : Dimension) {
    for(p<-Pixels){
      g.setPixel(p.x + offset.width, p.y + offset.height, p.TRGB)
    }
  }
}

case class Pixel (x : Byte, y : Byte, TRGB : Byte)